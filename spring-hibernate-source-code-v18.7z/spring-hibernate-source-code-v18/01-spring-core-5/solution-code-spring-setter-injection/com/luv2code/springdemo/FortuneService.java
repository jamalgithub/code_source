package com.luv2code.springdemo;

public interface FortuneService {

	public String getFortune();
	
}
