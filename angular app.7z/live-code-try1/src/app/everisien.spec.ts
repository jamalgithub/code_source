import { Everisien } from './everisien';

describe('Everisien', () => {
  it('should create an instance', () => {
    expect(new Everisien()).toBeTruthy();
  });
});
