export class Everisien {
  name: string;
  level: string;
  date: string;
}
