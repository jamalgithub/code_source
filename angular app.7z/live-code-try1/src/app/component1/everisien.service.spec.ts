import { TestBed } from '@angular/core/testing';

import { EverisienService } from './everisien.service';

describe('EverisienService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EverisienService = TestBed.get(EverisienService);
    expect(service).toBeTruthy();
  });
});
