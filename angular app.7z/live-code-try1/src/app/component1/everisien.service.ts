import { Injectable } from "@angular/core";
import { Everisien } from "../everisien";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class EverisienService {
  everrisienList = new Array<Everisien>();

  constructor(private http: HttpClient) {}

  createEverisien(everisien: Everisien): Observable<Everisien> {
    this.everrisienList.push(everisien);
    return this.http.post<Everisien>("http://localhost:8080", everisien);
  }
  updateEverisien(everisien: Everisien, index: number) {
    this.deleteEverisien(index);
    this.everrisienList.push(everisien);
  }
  deleteEverisien(index: number) {
    this.everrisienList.splice(index, 1);
  }

  getAll(): Observable<Everisien[]> {
    return this.http.get<Everisien[]>("http://localhost:8080");
  }
}
