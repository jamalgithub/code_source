import { Component, OnInit } from "@angular/core";
import { Everisien } from "../everisien";
import { EverisienService } from "./everisien.service";
import { Observable } from "rxjs";

@Component({
  selector: "app-component1",
  templateUrl: "./component1.component.html",
  styleUrls: ["./component1.component.css"]
})
export class Component1Component implements OnInit {
  title = "Hello Everis";
  everrisienList: Array<Everisien>;

  everisien: Everisien;
  constructor(private everisienServie: EverisienService) {}

  ngOnInit() {
    this.everisien = new Everisien();
    this.everisienServie
      .getAll()
      .subscribe(elements => (this.everrisienList = elements));
  }

  onAdd(): void {
    let observable: Observable<
      Everisien
    > = this.everisienServie.createEverisien(this.everisien);
    let createdEverisien: Everisien;
    observable.subscribe(
      element => (createdEverisien = element),
      error => console.log(error)
    );
    this.everisien = new Everisien();
    this.everisienServie
      .getAll()
      .subscribe(elements => (this.everrisienList = elements));
  }
  onRemove(index: number): void {
    this.everisienServie.deleteEverisien(index);
  }

  onEdit(element: Everisien, index: number): void {
    this.everisienServie.updateEverisien(element, index);
  }
}
